import subprocess
import os
import pandas as pd

# Execute the command and retrieve the output
subprocess.run('rostopic echo -b my_recorded_data.txt.bag -p /europa_topic > test1.csv', capture_output=True, text=True, shell=True)
subprocess.run('rostopic echo -b my_recorded_data.txt.bag -p /sensing_topic > test2.csv', capture_output=True, text=True, shell=True)

df1 = pd.read_csv('test1.csv')
df2 = pd.read_csv('test2.csv')

merged_df = pd.concat([df1, df2], axis=1)
merged_df.to_csv('result.csv', index=False)
os.remove('test1.csv')
os.remove('test2.csv')
